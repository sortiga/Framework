<?php
   //include_once("config.php");
try
{     
   	set_time_limit(0); 

    require_once("Controller.php");
    
	
    $id = 1;	
/*	$database = new DatabaseMySQL;
	$database->SetId($id);
	$database->Get_Database($oConexao);
*/

    $objDatabase=new BALDatabaseMySQL(); 
    $objDatabase->SetId($id);  
    $result= $objDatabase->Get_Database($objDatabase); 
    //print "<script>alert('View');</script>"; 
    while($row = mysql_fetch_row($result)){ 
       //$tpDB = $row[5];
	   $objDatabase->SetIdTipoDatabase($row[5]);
	   //$usDB = $row[6];   //$user
	   $objDatabase->SetUsuario($row[6]);
	   //$pwDB = $row[7];   //$senha
	   $objDatabase->SetSenha($row[7]);
	   //$nmDB = $row[8];   //$server
	   $objDatabase->SetDatabase($row[8]);
	   //$scDB = $row[9];
	   $objDatabase->SetSchema($row[9]);
	   
	   // Obtem a senten�a a ser executada 
	   $resqueries= $objDatabase->Get_Queries($objDatabase);
       // Obtem as tabelas que possuem Qtd Pk = Qtd Fk e que tem PK composta 
	   $fim = $objDatabase->GetListaTab1($objDatabase,$resqueries);

    }
}
catch(Exception $e)
 {
   die("ERRO! Detalhes => " . $e->getMessage());
 }


	
?>