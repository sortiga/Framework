<?php
include_once('model.php');

class BALDatabaseMySQL extends AbstractDatabase 
{
	public function Get_Database(AbstractDatabase $objDatabase) {
	    $objiDatabase = new DALDatabaseMySQL;
		return $objiDatabase->Get_Database($objDatabase);
	}

	public function Get_Queries(AbstractDatabase $objDatabase) {
	    $objiDatabase = new DALDatabaseMySQL;
		return $objiDatabase->Get_Queries($objDatabase);
	}
	
	Public function GetListaTab1(AbstractDatabase $objDatabase,$resqueries){
       If ($query1 = mysql_fetch_row($resqueries,$objDatabase->GetIdTipoDatabase())) {	   
       	   $sql = $query1[2];
   	       $objiDatabase = new DALDatabaseMySQL;
		   $tab_tot_pk_fk = $objiDatabase->GetListaTab1($objDatabase,$sql);   

           echo '<h5>Exibindo dados retornados pela extens�o PDO"</h5>';
           echo "<table border='1'>\n";
           foreach($tab_tot_pk_fk as $row ) 
           {
             echo "<tr>\n";
             $ind = 0;
             foreach ($row as $item) 
             {
               echo "    <td>".($item!==null?htmlentities($item, ENT_QUOTES):" ")."</td>\r\n";
               $col[$ind] = $item;
               $ind++;
             }
 /*            $owner = $col[0];
             $table = $col[1];
             If ($query1 = mysql_fetch_row($resqueries)) {	   
	               $sql = $query1[2];
                //Query que obtem as colunas que fazem parte da PK
                if(!$stmt = $pdo->prepare($sql))
                {
                  $e= $pdo->errorInfo();
                  throw new Exception("Erro ao preparar consulta - " . $e[2]);
                }
                if(!$stmt->execute())
                {
                  $e= $stmt->errorInfo();
                  throw new Exception("Erro ao preparar consulta - " . $e[2]);
                }
			 }
   */
             echo "</tr>\n";
			} 
        }
       echo "</table>\n";
	}
	
}
?>