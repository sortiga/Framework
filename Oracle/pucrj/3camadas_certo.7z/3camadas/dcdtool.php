<?php
   //include_once("config.php");
try
{     
   	set_time_limit(0); 

    require_once("Controller.php");
    
	
    $id = 1;	
/*	$database = new DatabaseMySQL;
	$database->SetId($id);
	$database->Get_Database($oConexao);
*/

    $objDatabase=new BALDatabaseMySQL(); 
    $objDatabase->SetId($id);  
    $result= $objDatabase->Get_Database($objDatabase); 
    //print "<script>alert('View');</script>"; 
    while($row = mysql_fetch_row($result)){ 
       //$tpDB = $row[5];
	   $objDatabase->SetIdTipoDatabase($row[5]);
	   //$usDB = $row[6];   //$user
	   $objDatabase->SetUsuario($row[6]);
	   //$pwDB = $row[7];   //$senha
	   $objDatabase->SetSenha($row[7]);
	   //$nmDB = $row[8];   //$server
	   $objDatabase->SetDatabase($row[8]);
	   //$scDB = $row[9];
	   $objDatabase->SetSchema($row[9]);
	   
	   // Obtem a senten�a a ser executada 
	   $resqueries= $objDatabase->Get_Queries($objDatabase);
       // Obtem as tabelas que possuem Qtd Pk = Qtd Fk e que tem P 

       If ($query1 = mysql_fetch_row($resqueries)) {	   
       	   $sql = $query1[2];
       	   
       	   // Monta a string de conex�o de acordo com o tipo do BD
       	   if ($objDatabase->GetIdTipoDatabase() == 1) {
       	     $conDB = "oci:dbname=".$objDatabase->GetDatabase();
       	   }
       	   
       	   if ($objDatabase->GetIdTipoDatabase() == 2) {
       	     $conDB = "mysql:host=".$objDatabase->GetDatabase().";dbname=".$$objDatabase->GetSchema();
       	   }
       
              try
                {
              	   $pdo = new PDO($conDB,$objDatabase->GetUsuario(),$objDatabase->GetSenha());
                }
                catch(PDOException $e) 
                {
                  throw new Exception("Erro ao conectar ao servidor " . $e->getMessage());
                }
                if(!$stmt = $pdo->prepare($sql))
                {
                  $e= $pdo->errorInfo();
                  throw new Exception("Erro ao preparar consulta - " . $e[2]);
                }
                if(!$stmt->execute())
                {
                  $e= $stmt->errorInfo();
                  throw new Exception("Erro ao preparar consulta - " . $e[2]);
                }

                if($tab_tot_pk_fk = $stmt->fetchAll(PDO::FETCH_ASSOC))
                {
                  echo '<h5>Exibindo dados retornados pela extens�o PDO"</h5>';
                  echo "<table border='1'>\n";
                  foreach($tab_tot_pk_fk as $row ) 
                  {
                    echo "<tr>\n";
                    $ind = 0;
                    foreach ($row as $item) 
                    {
                      echo "    <td>".($item!==null?htmlentities($item, ENT_QUOTES):" ")."</td>\r\n";
                        $col[$ind] = $item;
						$ind++;
                    }
					$owner = $col[0];
					$table = $col[1];
					If ($query1 = mysql_fetch_row($resqueries)) {	   
       	               $sql = $query1[2];
					   //Query que obtem as colunas que fazem parte da PK
                       if(!$stmt = $pdo->prepare($sql))
                       {
                         $e= $pdo->errorInfo();
                         throw new Exception("Erro ao preparar consulta - " . $e[2]);
                       }
                       if(!$stmt->execute())
                       {
                         $e= $stmt->errorInfo();
                         throw new Exception("Erro ao preparar consulta - " . $e[2]);
                       }
					   
					}
                    echo "</tr>\n";
                  }
                  echo "</table>\n";
                }
                else
                {
                  echo '<h5>A consulta n�o retornou dados.</h5>';
                }
       }
    }
}
catch(Exception $e)
 {
   die("ERRO! Detalhes => " . $e->getMessage());
 }


	
?>