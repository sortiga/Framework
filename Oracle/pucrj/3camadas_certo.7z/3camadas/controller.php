<?php
include_once('model.php');

class BALDatabaseMySQL extends AbstractDatabase 
{
	public function Get_Database(AbstractDatabase $objDatabase) {
	    $objiDatabase = new DALDatabaseMySQL;
		return $objiDatabase->Get_Database($objDatabase);
	}

	public function Get_Queries(AbstractDatabase $objDatabase) {
	    $objiDatabase = new DALDatabaseMySQL;
		return $objiDatabase->Get_Queries($objDatabase);
	}
	
	
}
?>