<?php
	session_start();
	require_once("../../engine/conexao.php");
	require_once("../../engine/funcoes.php");
	logado();
	//adm();
	mantemLogin();
	
	if($_GET){
	    //echo "<pre>";
		//print_r($_GET);
		//echo "</pre>";
		extract($_GET);
		//echo "ID = $id";
		//exit;
		
		$SQL = "SELECT * FROM modelos WHERE idModelos = $id;";
		//echo "SQL = $SQL";
		//exit;
		$resultado = mysqli_query($conexao,$SQL);
		
	    $linhas = mysqli_affected_rows($conexao);
		//echo "Linhas = $linhas";
		//exit;
        if($linhas > 0){
  		   $linha = mysqli_fetch_array($resultado);
		   extract($linha);		   

		   $SQL2 = "SELECT nome as nmtabela FROM tabelas WHERE idTabelas = $idFactTable;";
		   //echo "SQL = $SQL";
		   //exit;
		   $resultado2 = mysqli_query($conexao,$SQL2);
		   $linhas2 = mysqli_affected_rows($conexao);
           if($linhas > 0){
				$linha2 = mysqli_fetch_array($resultado2);
				extract($linha2);		   
			}else{
				$_SESSION['msg'] = "Falha - Não foi possível recuperar a Tabela Fato do modelo informado.";
				header("location: index_01.php");
			}		
	    }else{
		   $_SESSION['msg'] = "Falha - Não foi possível recuperar o modelo informado.";
		   header("location: index_01.php");
        }		

	    //echo "<pre>";
		//print_r($linha);
		//echo "</pre>";
		//extract($_GET);
		//echo "ID = $id";
		//exit;
	}

	if($_POST){
      header("location: index_01.php");
	  echo "POST";
	  exit;
	}
	
	include_once("../topo.php");
?>
<!-- Inner Container Start -->
<div class="container">
<form class="mws-form" action="" method="post" enctype="multipart/form-data">
  <div class="mws-panel grid_8">
   <div class="mws-panel-header">
    <span class="mws-i-24 i-list">Consultar Modelo</span>
  </div>
  <div class="mws-panel-body">
   <div class="mws-form-block">

    <div class="mws-form-row">
      <label for="nome">Modelo</label>
      <div class="mws-form-item large">
        <input type="text" id ="nome" name="nome" value="<?=$nome;?>" class="mws-textinput" disabled="disabled"/>
      </div>
      <label for="descricao">Descri&ccedil;&atilde;o</label>
      <div class="mws-form-item large">
        <input type="text" id ="descricao" name="descricao" value="<?=$descricao;?>" class="mws-textinput" disabled="disabled"/>
      </div>
      <label for="nmtabela">Tabela Fato do Modelo</label>
      <div class="mws-form-item large">
        <input type="text" id ="nmtabela" name="nmtabela" value="<?=$nmtabela;?>" class="mws-textinput" disabled="disabled" />
      </div>
    </div>
</div>
<div class="mws-button-row">
    <input type="submit" value="Retornar" class="mws-button orange" />
	<input type="hidden" name="id" value="<?=$id;?>"/>
</div>
</div>     
</div>
</form>    
</div>
<?php
	include_once("../rodape.php");
?>
